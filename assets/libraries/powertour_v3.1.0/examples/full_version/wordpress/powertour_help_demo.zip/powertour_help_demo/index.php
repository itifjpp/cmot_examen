<?php get_header(); ?>

	<!-- trigger -->
    
    <a href="javascript:void(0);" id="powertour-demo-trigger-id">
    	Run power tour
        <span>(trigger)</span>
    </a>
    
    <!-- demo box -->
    
    <div class="powertour-demo-box" id="powertour-demo-box-1">
    	<p>Demo box 1</p>
        <span>(hookTo)</span>
    </div>    

    <div class="powertour-demo-box" id="powertour-demo-box-2">
    	<p>Demo box 2</p>
        <span>(hookTo)</span>
    </div> 
     
    <div class="powertour-demo-box" id="powertour-demo-box-3">
    	<p>Demo box 3</p>
        <span>(hookTo)</span>
    </div> 
    
    <!-- demo guid(not needed) -->
    
    <div id="guide">
    Notice that every theme is different!
    </div> 
    
    <!-- below this line are the steps ( your can add these blocks to the footer.php file if needed)-->
    
    <div class="single-step" id="step-id-1">
        <h3>Step one</h3>
        <p>This is the first step. I should be below 'demo box 1'.</p>
        <br/>
        <a href="#" data-powertour-action="next">Next step...</a>
    </div>
    
    <div class="single-step" id="step-id-2">
        <h3>Step two</h3>
        <p>This is the second step and should be located next(left side) to 'demo box 2'.</p>
        <br/>
        <a href="#" data-powertour-action="prev">Prev step</a>
        <a href="#" data-powertour-action="next" style="float:right">Next step</a>
    </div>
    
    <div class="single-step" id="step-id-3">
        <h3>Step three</h3>
        <p>This is the third and last step and should be located above(with offset) 'demo box 3'.</p>
        <br/>
        <a href="#" data-powertour-action="prev">Prev step...</a>
        <a href="#" data-powertour-action="stop" style="float:right">End tour</a>
    </div>                    

<?php get_footer();
