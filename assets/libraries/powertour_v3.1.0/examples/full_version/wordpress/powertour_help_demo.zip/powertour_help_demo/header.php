<!DOCTYPE html>
<html>
<head>
	<title>Power Tour help demo...</title>
	<?php wp_head(); ?>

    <!-- POWERTOUR JS CORE -->    
    <script src="<?php echo get_template_directory_uri(); ?>/js/powertour.2.5.1.js"></script>   
    
    <!-- POWERTOUR CSS CORE -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/powertour.2.5.1.css"/>      
    
    <!-- POWERTOUR STYLING -->    
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/powertour-style-clean.css"/>
    
    <!-- POWERTOUR ANIMATIONS(optional if you are using fx) -->
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/animate.min.css"/>

    <!-- POWERTOUR SETUP -->
	<script>
		jQuery(document).ready(function($){
			$.powerTour({
				tours : [
					{
						trigger            : '#powertour-demo-trigger-id',
						startWith          : 1,
						easyCancel         : true,
						escKeyCancel       : true,
						scrollHorizontal   : false,
						keyboardNavigation : true,
						loopTour           : false,
						highlightStartSpeed: 200,// new 2.5.0
						highlightEndSpeed  : 200,// new 2.3.0
						onStartTour        : function(ui){ },
						onEndTour          : function(ui){ },	
						onProgress         : function(ui){ },
						steps : [
							  {
								  hookTo          : '#powertour-demo-box-1',
								  content         : '#step-id-1',
								  width           : 400,
								  position        : 'bm',
								  offsetY         : 20,
								  offsetX         : 0,
								  fxIn            : 'flipInX',
								  fxOut           : 'bounceOutLeft',
								  showStepDelay   : 0,
								  center          : 'step',
								  scrollSpeed     : 400,
								  scrollEasing    : 'swing',
								  scrollDelay     : 0,
								  timer           : '00:00',
								  highlight       : false,
								  keepHighlighted : false,
								  keepVisible     : false,// new 2.2.0
								  onShowStep      : function(ui){},
								  onHideStep      : function(ui){ }
							  },
							  {
								  hookTo          : '#powertour-demo-box-2',
								  content         : '#step-id-2',
								  width           : 300,
								  position        : 'lt',
								  offsetY         : 0,
								  offsetX         : 20,
								  fxIn            : 'fadeIn',
								  fxOut           : 'fadeOut',
								  showStepDelay   : 0,
								  center          : 'step',
								  scrollSpeed     : 400,
								  scrollEasing    : 'swing',
								  scrollDelay     : 0,
								  timer           : '00:00',
								  highlight       : true,
								  keepHighlighted : false,
								  keepVisible     : false,// new 2.2.0
								  onShowStep      : function(ui){},
								  onHideStep      : function(ui){ }
							  },
							  {
								  hookTo          : '#powertour-demo-box-3',
								  content         : '#step-id-3',
								  width           : 400,
								  position        : 'tl',
								  offsetY         : -40,
								  offsetX         : 40,
								  fxIn            : 'rotateIn',
								  fxOut           : 'rotateOut',
								  showStepDelay   : 0,
								  center          : 'step',
								  scrollSpeed     : 400,
								  scrollEasing    : 'swing',
								  scrollDelay     : 0,
								  timer           : '00:00',
								  highlight       : false,
								  keepHighlighted : false,
								  keepVisible     : false,// new 2.2.0
								  onShowStep      : function(ui){},
								  onHideStep      : function(ui){ }
							  }		
						],
						stepDefaults : [
							{
								width           : 300,
								position        : 'tr',
								offsetY         : 0,
								offsetX         : 0,
								fxIn            : 'fadeIn',
								fxOut           : 'fadeOut',
								showStepDelay   : 0,
								center          : 'step',
								scrollSpeed     : 400,
								scrollEasing    : 'swing',
								scrollDelay     : 0,
								timer           : '00:00',
								highlight       : true,
								keepHighlighted : false,
								keepVisible     : false,// new 2.2.0
								onShowStep      : function(ui){ },
								onHideStep      : function(ui){ }
							}
						 ]
					}
				]
			});	
		});	
	</script>
    
	<!-- DEMO (not needed) -->
    <style>	
		body{
			font-family:Verdana, Geneva, sans-serif;
			line-height:24px;
			font-size:12px;
			color:#555;
		}
		
		#powertour-demo-trigger-id{
			margin:80px auto 0 auto;			
			height:60px; 
			width:240px; 
			text-align:center; 
			background-color:#2854a1;
			color:#fff;
			text-decoration:none;
			display: block;
			line-height:45px;
			text-transform:uppercase;
			font-size:12px;
			border-radius:5px;
		}
			#powertour-demo-trigger-id > span{
				clear:both;
				width:100%;
				float:left;
				line-height:0;
				font-size:10px;
				margin-top:-5px;
				text-transform:lowercase
			}
		.powertour-demo-box{
			margin:20px auto 0 auto;			
			height:200px; 
			width:240px; 
			text-align:center; 
			background-color:#fff;
			border:1px solid #ccc;
			text-decoration:none;
			display: block;			
			font-size:12px;
			border-radius:5px;	
		}
			.powertour-demo-box > p{
				line-height:160px;
				text-transform:uppercase;
			}
			.powertour-demo-box > span{
				clear:both;
				width:100%;
				float:left;
				line-height:14px;
				font-size:10px;
				margin-top:-80px;
				text-transform:lowercase
			}
		#guide{
			margin:20px auto 80px auto;
			padding:20px;			
			width:200px; 
			text-align:center; 
			background-color:#fff;
			border:1px solid #ccc;
			text-decoration:none;
			display: block;			
			font-size:12px;
			border-radius:5px;	
		}
	</style>
</head>
<body>